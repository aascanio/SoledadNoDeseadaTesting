function HeadTitle(props) {


    return (<div className="head-title">
        <p className="head-title-text">{props.title}</p>
    </div>)
}


export default HeadTitle;